---
name: Discussion
about: Ideas sharing or theorical question solving 
labels: question
title: "[Discussion] your question"
---

<!-- Please respect the title [Discussion] tag. -->
